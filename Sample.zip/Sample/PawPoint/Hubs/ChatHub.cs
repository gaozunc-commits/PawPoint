using Microsoft.AspNetCore.SignalR;

namespace Demo.Hubs;

public class ChatHub : Hub
{
    public async Task SendMessage(string user, string role, string message)
    {
        var time = DateTime.Now.ToString("HH:mm");
        await Clients.All.SendAsync("ReceiveMessage", user, role, message, time);
    }
}

# PawPoint — Full Technical Architecture & Build Specification (v2)

**Project:** PawPoint — Multi-Branch Pet Grooming & Pet Care Appointment System
**Course:** AMIT2014 Web and Mobile Systems
**Stack:** .NET 10, ASP.NET Core MVC, C# (all views are `.cshtml` Razor — this is a server-rendered MVC app, not an SPA/API-first build), Entity Framework Core (code-first, data annotations), SQL Server Express (file-based, `DB.mdf`), manual cookie authentication, jQuery + Unobtrusive AJAX, plain custom CSS (`wwwroot/css/app.css`) — **no Bootstrap or other CSS framework**, unless a later practical you provide introduces one.

> **v2 changelog:** corrected against `Practical_01_and_02_Database_SELECT.md`. Removed the Bootstrap assumption; added the exact `DB.cs`/`Program.cs` skeleton; documented the plain (non-AJAX) filter/search/sort/paging baseline that every listing page starts from before AJAX is layered on top; added the `data-get` navigation-button convention; added `_ViewImports`/`_ViewStart` conventions; added project cleanup step to the submission checklist.

---

## 0. Non-negotiable coding conventions

These come directly from the course practicals and must be followed everywhere — consistency across all four members' modules is itself a graded rubric item (General Web Architecture).

1. File-scoped namespaces (`namespace Demo.Models;`), no ASP.NET Core Identity, no Fluent API — data annotations only.
2. One `DB : DbContext` class holding every `DbSet<T>`, using the exact constructor pattern:
   ```csharp
   using Microsoft.EntityFrameworkCore;
   namespace Demo.Models;

   public class DB(DbContextOptions options) : DbContext(options)
   {
       public DbSet<Admin> Admins { get; set; }
       public DbSet<Staff> Staffs { get; set; }
       public DbSet<Customer> Customers { get; set; }
       public DbSet<Branch> Branches { get; set; }
       // ... one DbSet per entity in §2
   }
   ```
3. One `Helper` class (constructor-injected `IWebHostEnvironment en`, `IHttpContextAccessor ct`) holding all cross-cutting logic: password hashing, sign-in/out, photo save/validate/delete, cart get/set, email sending. No repository/service/unit-of-work layers.
4. Controllers use primary constructor injection: `public class XController(DB db, Helper hp) : Controller`.
5. TPH inheritance for the user hierarchy (`User` base class, `Admin`/`Staff`/`Customer` subclasses), `Role => GetType().Name` computed property.
6. Every insert/update form has a dedicated `XxxVM` in `Models/ViewModels.cs`, annotated with the same rules as the entity, plus `[Remote]` for async uniqueness/existence checks backed by a plain `bool` GET action. These POST forms use **Tag Helpers** (`asp-for`, `asp-validation-for`) bound to the VM.
7. GET-based **listing pages** (filter/search/sort/paging query strings) use classic **HTML Helpers**, not tag helpers, so the submitted value is retained automatically:
   ```razor
   @Html.TextBox("name", "", new { type = "search", autofocus = "", data_trim = "" })
   @Html.Hidden("sort")
   @Html.Hidden("dir")
   ```
8. Controller validation idiom (use exactly this shape everywhere):
   ```csharp
   if (ModelState.IsValid("Id") && db.Table.Any(x => x.Id == vm.Id))
   {
       ModelState.AddModelError("Id", "Duplicated Id.");
   }
   if (ModelState.IsValid)
   {
       // persist
       TempData["Info"] = "Record inserted.";
       return RedirectToAction("Index");
   }
   // re-populate any ViewBag lookups
   return View(vm);
   ```
9. `TempData["Info"]` for post-redirect success messages.
10. Single delete: `[HttpPost] Delete(string? id)` → find → remove if found → `TempData["Info"]` → `return Redirect(Request.Headers.Referer.ToString());`. Batch delete: `db.Table.Where(...).ExecuteDelete()` + `data-checkable` row convention.
11. **Navigation buttons** that are styled as `<button>` (not `<a>`) use `data-get="/Controller/Action/id"`; a delegated click handler in `wwwroot/js/app.js` performs `location.href = this.dataset.get`. Use this instead of wrapping an `<a>` in button styling.
12. **Listing pages — baseline (non-AJAX) pattern, then layer AJAX on top:**
    - Filtering: `db.Table.Where(x => x.FkId == fkId || fkId == null)` — the `|| paramIsNull` idiom, not an `if`-branch.
    - Searching: trim server-side (`name = name?.Trim() ?? ""`), `Where(x => x.Name.Contains(name))`, input rendered via `@Html.TextBox("name", "", new { type = "search", autofocus = "", data_trim = "" })` so the submitted value round-trips into the box.
    - Sorting: `Func<T, object> fn = sort switch { "Field" => x => x.Field, ..., _ => x => x.Id }; var m = dir == "des" ? db.Table.OrderByDescending(fn) : db.Table.OrderBy(fn);` — column headers are `<a href="?sort=Field&dir=asc|des">` links with `asc`/`des` CSS classes for the `▲`/`▼` indicator (`app.css`). Note: because `fn` is a `Func<T,object>` variable (not an inline lambda), this resolves to `Enumerable.OrderBy`, not `Queryable.OrderBy` — the table is pulled into memory before sorting. This is the taught idiom; keep it exactly like this for style consistency rather than "fixing" it to an `Expression<Func<...>>` version.
    - Paging: `X.PagedList.Extensions` → `db.Table.ToPagedList(page, 10)`, `IPagedList<T>` as the view model, `@Html.PagedListPager(Model, page => $"?...&page={page}", PagedListRenderOptions.ClassicPlusFirstAndLast)`, with the `page < 1` / `page > PageCount` redirect guards shown in Practical 02 Demo 4/5.
    - Combined search+sort+page actions retain all three via query string on every link/pager/hidden field (see Practical 02 Demo 5) — this is the pattern every AJAX-enhanced index page in PawPoint should be built on top of, not instead of.
    - **AJAX layer (Practical 03, applied on top of the above):** the same action branches on `Request.IsAjax()` to return `PartialView("_A", m)` instead of `View(m)`; the search `<form>`/sort `<a>`/pager get `data-ajax="true" data-ajax-update="#target" data-ajax-loading="#loader"` attributes so the page updates without a full reload, but the underlying query/filter/sort/paging C# logic is unchanged from the baseline pattern above.
13. AJAX partials named `_A.cshtml`, `_B.cshtml`, `_C.cshtml` by concern (list body / sortable header / pager), included via `<partial name="_A" />`.
14. Photo upload via `SixLabors.ImageSharp`, saved as `Guid.NewGuid().ToString("n") + ".jpg"` under `wwwroot/<folder>/`, validated in `Helper.ValidatePhoto(IFormFile)` returning `""` or an error string.
15. Security: `AddAuthentication().AddCookie()`, `PasswordHasher<object>`, claims = `ClaimTypes.Name` (email) + `ClaimTypes.Role`, `[Authorize(Roles = "...")]` on every protected controller/action.
16. `DateOnly`/`TimeOnly` for pure date/time fields (appointment date, time slot).
17. No Bootstrap, no CSS framework — one shared `wwwroot/css/app.css` and `wwwroot/js/app.js`, grown incrementally the way the practicals do (plain semantic HTML — `<table class="table">`, `<nav>`, `<header>`, `<main>`, `<footer>` — styled by hand).

---

## 1. `Program.cs` (exact skeleton)

```csharp
global using Demo.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSqlServer<DB>($@"
    Data Source=(LocalDB)\MSSQLLocalDB;
    AttachDbFilename={builder.Environment.ContentRootPath}\DB.mdf;
");
builder.Services.AddScoped<Helper>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddAuthentication().AddCookie();
builder.Services.AddSession();
builder.Services.AddSignalR(); // only if the real-time chat AF is implemented

var app = builder.Build();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();
app.MapDefaultControllerRoute();
app.MapHub<ChatHub>("/chatHub"); // only if chat AF implemented
app.Run();
```

### Required NuGet packages
- `Microsoft.EntityFrameworkCore.SqlServer`
- `Microsoft.EntityFrameworkCore.Tools`
- `Microsoft.EntityFrameworkCore.Design`
- `X.PagedList.Mvc.Core`
- `SixLabors.ImageSharp`
- `Stripe.net` (only if the Stripe deposit AF is implemented)

### Required client libraries (`libman.json`, from `cdnjs`, into `wwwroot/js/`)
- `jquery@3.7.1`
- `jquery-ajax-unobtrusive@3.2.6`
- `jquery-validate@1.21.0`
- `jquery-validation-unobtrusive@4.0.0`

---

## 2. Layout & view-start conventions

### `Views/Shared/_Layout.cshtml`
Plain HTML skeleton (`<header>`, `<nav>`, `<main>`, `<footer>`), page title from `@ViewBag.Title`, role-based nav links trimmed with `@if (User.IsInRole("..."))`, one stylesheet (`/css/app.css`), the four JS libraries above plus `/js/app.js`, `@RenderSection("head", false)` / `@RenderSection("foot", false)` for per-page extras.

### `Views/_ViewImports.cshtml`
```razor
@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
```

### `Views/_ViewStart.cshtml`
```razor
@{
    Layout = "_Layout";
    ViewBag.Title = "Untitled";
}
```
Every view overrides `ViewBag.Title` in its own `@{ }` block (e.g. `"Pet | Index"`).

### `wwwroot/js/app.js` must include (minimum)
- A delegated click handler for `[data-get]` elements → `location.href = this.dataset.get`.
- A `data-trim` handler that trims search inputs client-side before submit.
- Any AJAX loading-indicator show/hide wiring used by `data-ajax-loading`.

---

## 3. Roles & access matrix

| Role | Can access |
| :-- | :-- |
| **Admin** | Everything: branch/staff/service/product maintenance, all appointments, all orders, reports. |
| **Staff** | Their own branch's appointments (view/update status), their assigned services, their branch's product stock view. Cannot manage branches or other staff. |
| **Customer** | Their own pets, bookings, cart, orders, reviews, profile. |
| **Anonymous** | Home/landing page, service catalog browse (read-only), register, login. |

---

## 4. Entity model (`Models/DB.cs` + one class per entity)

### 4.1 User hierarchy (TPH)
```
User (base class)
  Email        string  [Key, MaxLength(100)]
  Hash         string  [MaxLength(100)]
  Name         string  [MaxLength(100)]
  Phone        string  [MaxLength(20)]
  Role         string  => GetType().Name   [NotMapped]

Admin : User
  (no extra fields)

Staff : User
  PhotoURL     string  [MaxLength(100)]
  BranchId     string  FK -> Branch
  Branch       Branch (nav)
  StaffServices ICollection<StaffService>
  Appointments ICollection<Appointment>   (assigned)

Customer : User
  PhotoURL     string  [MaxLength(100)]
  Points       int     (reward points, default 0)
  Pets         ICollection<Pet>
  Orders       ICollection<Order>
  Reviews      ICollection<Review>
```

### 4.2 Branch / Service / Staff assignment
```
Branch
  Id       string  [Key, MaxLength(6), RegularExpression(@"BR\d{3}")]
  Name     string  [MaxLength(100)]
  Address  string  [MaxLength(200)]
  Phone    string  [MaxLength(20)]
  Latitude   double?   (for Maps AF)
  Longitude  double?
  Staff    ICollection<Staff>
  Services ICollection<Service>
  Appointments ICollection<Appointment>

Service
  Id          string  [Key, MaxLength(6), RegularExpression(@"SV\d{3}")]
  Name        string  [MaxLength(100)]
  Description string  [MaxLength(500)]
  Price       decimal [Range(0.01, 999.99)]
  DurationMinutes int [Range(10, 240)]
  PhotoURL    string  [MaxLength(100)]
  BranchId    string  FK -> Branch
  StaffServices ICollection<StaffService>
  AppointmentServices ICollection<AppointmentService>

StaffService   (M:M junction, composite key StaffEmail + ServiceId)
  StaffEmail  string  FK -> Staff
  ServiceId   string  FK -> Service
```

### 4.3 Pets & Appointments
```
Pet
  Id            int     [Key, Identity]
  Name          string  [MaxLength(50)]
  Species       string  [MaxLength(30)]   (Dog/Cat/Other)
  Breed         string  [MaxLength(50)]
  DOB           DateOnly?
  PhotoURL      string  [MaxLength(100)]
  CustomerEmail string  FK -> Customer
  Appointments  ICollection<Appointment>

Appointment
  Id            int      [Key, Identity]
  PetId         int      FK -> Pet
  StaffEmail    string   FK -> Staff
  BranchId      string   FK -> Branch
  Date          DateOnly
  TimeSlot      TimeOnly
  Status        string   [RegularExpression(@"Pending|Confirmed|Completed|Cancelled")]
  Notes         string?  [MaxLength(300)]
  CreatedAt     DateTime
  AppointmentServices ICollection<AppointmentService>
  Review        Review?

AppointmentService  (M:M junction, composite key AppointmentId + ServiceId)
  AppointmentId int     FK -> Appointment
  ServiceId     string  FK -> Service
  Price         decimal  (price snapshot at booking time)
```

### 4.4 Retail add-on (grooming supplies)
```
Product
  Id          string  [Key, MaxLength(6), RegularExpression(@"PR\d{3}")]
  Name        string  [MaxLength(100)]
  Description string  [MaxLength(500)]
  Price       decimal [Range(0.01, 999.99)]
  Stock       int     [Range(0, 9999)]
  PhotoURL    string  [MaxLength(100)]
  OrderLines  ICollection<OrderLine>

Order
  Id            int     [Key, Identity]
  CustomerEmail string  FK -> Customer
  Date          DateOnly
  Status        string  [RegularExpression(@"Pending|Paid|Completed|Cancelled")]
  Paid          bool
  OrderLines    ICollection<OrderLine>

OrderLine
  Id        int     [Key, Identity]
  OrderId   int     FK -> Order
  ProductId string  FK -> Product
  Quantity  int     [Range(1, 20)]
  Price     decimal  (price snapshot at order time)
```

### 4.5 Reviews, notifications, loyalty
```
Review
  Id            int      [Key, Identity]
  AppointmentId int      FK -> Appointment (unique — 1:1)
  CustomerEmail string   FK -> Customer
  Rating        int      [Range(1, 5)]
  Comment       string?  [MaxLength(500)]
  CreatedAt     DateTime

Notification
  Id            int      [Key, Identity]
  CustomerEmail string   FK -> Customer
  Channel       string   [RegularExpression(@"Email|SMS")]
  Message       string   [MaxLength(500)]
  SentAt        DateTime

RewardTransaction
  Id            int      [Key, Identity]
  CustomerEmail string   FK -> Customer
  Points        int       (+ earn / - redeem)
  Reason        string   [MaxLength(200)]
  CreatedAt     DateTime
```

---

## 5. View Models (`Models/ViewModels.cs`)

One VM per form, Insert/Update split as needed, bound via Tag Helpers on POST:

- `LoginVM` (Email, Password, RememberMe)
- `RegisterVM` (Email [Remote CheckEmail], Password, ConfirmPassword [Compare], Name, Phone, Photo)
- `UpdatePasswordVM` (Current, New, ConfirmNew)
- `ResetPasswordVM` (Email)
- `BranchInsertVM` / `BranchUpdateVM`
- `StaffInsertVM` (Email [Remote CheckEmail], Name, Phone, Password, BranchId, Photo, ServiceIds[]) / `StaffUpdateVM` (no password/email edit, Photo optional)
- `ServiceInsertVM` / `ServiceUpdateVM` (Id [Remote CheckId], Name, Description, Price, DurationMinutes, BranchId, Photo optional on update)
- `PetInsertVM` / `PetUpdateVM` (Name, Species, Breed, DOB, Photo)
- `AppointmentBookVM` (PetId, BranchId, ServiceIds[], Date, TimeSlot, StaffEmail?, Notes)
- `AppointmentStatusVM` (Id, Status)
- `ProductInsertVM` / `ProductUpdateVM` (Id [Remote CheckId], Name, Description, Price, Stock, Photo)
- `CheckoutVM` (DeliveryAddress optional, PaymentMethod)
- `ReviewInsertVM` (AppointmentId, Rating, Comment)

Apply `[StringLength]`/`[MaxLength]`, `[Range]`, `[RegularExpression(..., ErrorMessage = "Invalid {0}.")]`, `[Remote("CheckX", "Controller", ErrorMessage = "Duplicated {0}.")]`, `[Compare]`, `[EmailAddress]` consistently with the entity-level constraints in §4.

**GET listing/search/filter query parameters are plain method parameters (`string? name`, `string? sort`, `int page = 1`), not view models** — per §0.7/§0.12, these use HTML Helpers reading straight off the query string, not model binding to a VM class.

---

## 6. Controllers & actions

| Controller | Access | Actions |
| :-- | :-- | :-- |
| `HomeController` | Anon | `Index` (landing), `About`, `ServiceCatalog` (filter/search/sort/paging over `Service` across branches, baseline + AJAX per §0.12) |
| `AccountController` | Anon/Auth | `Login` (GET/POST), `Logout`, `Register` (GET/POST, incl. photo + OTP AF), `VerifyOtp` (GET/POST) `[AF]`, `UpdatePassword` `[Authorize]`, `ResetPassword` (GET/POST) `[AF]`, `CheckEmail` (Remote) |
| `BranchController` | `Admin` | `Index` (filter/sort/paging + AJAX), `Insert`, `Update`, `Delete`, `CheckId` |
| `StaffController` | `Admin` | `Index`, `Insert` (incl. service assignment checkbox list), `Update`, `Delete`, `CheckEmail`, `AssignServices` (M:M) |
| `ServiceController` | `Admin` (write), Anon (read via catalog) | `Index`, `Insert`, `Update`, `Delete`, `CheckId` |
| `PetController` | `Customer` | `Index` (own pets), `Insert`, `Update`, `Delete`, photo upload |
| `AppointmentController` | `Customer` (book/cancel/history), `Staff`/`Admin` (manage) | `Book` (GET/POST), `Availability` (matrix grid, §7.1), `MyAppointments` (filter/paging), `Cancel`, `StaffIndex` (filter by branch/status/paging), `UpdateStatus`, `Detail`, `QrCheckIn` `[AF]` |
| `ProductController` | Anon/Customer read, `Admin` write | `Catalog` (search/filter/sort/paging), `Insert`, `Update`, `Delete`, `CheckId`, `AddToCart`, `UpdateCart`, `Cart`, `RemoveFromCart` |
| `OrderController` | `Customer` | `Checkout`, `OrderComplete`, `OrderHistory` (paging), `OrderDetail`, `PayDeposit` `[AF]` |
| `ReviewController` | `Customer` (insert own), Anon (read) | `Insert` (completed appointments only, one per appointment), `Index` (by service/staff) |
| `ReportController` | `Admin`/`Staff` | `RevenueChart` `[AF]`, `BookingsChart` `[AF]`, `LoyaltyChart` `[AF]` |
| `ChatController` / SignalR `ChatHub` | `Customer`/`Staff` | Real-time support chat `[AF]` |

Every write-capable action must carry `[Authorize(Roles = "...")]` unless explicitly Anon. Audit this manually before submission.

---

## 7. Key mechanisms

### 7.1 Slot availability matrix
`AppointmentController.Availability(string branchId, DateOnly? week)` builds a `Dictionary<Staff, List<TimeOnly>>` of booked slots by iterating the date/time range and marking booked vs free, rendered as an `x`/`o` grid (same construction technique as the room-reservation matrix taught elsewhere in the course). This becomes the customer-facing booking calendar and the staff-facing schedule view.

### 7.2 Cart (product add-on)
`Helper.GetCart()`/`SetCart()` backed by generic `ISession.Get<T>()/Set<T>()` JSON extensions, storing `Dictionary<string productId, int quantity>`. `Checkout` builds `Order` + `OrderLine`s from the session cart, snapshotting `Price`, then clears the session cart.

### 7.3 Appointment booking as multi-service selection
Booking form uses a reusable `_CheckBoxList.cshtml` partial to let the customer multi-select services for one appointment, persisted into `AppointmentService` rows with price snapshots.

### 7.4 Security
TPH `User`/`Admin`/`Staff`/`Customer`, `PasswordHasher<object>`, claims-based cookie sign-in, `_Layout.cshtml` role-based menu trimming via `User.IsInRole(...)`.

### 7.5 Notifications
`Helper.SendEmail(...)` via Gmail SMTP App Password, triggered on: registration OTP, password reset, appointment confirmation, appointment reminder, order e-receipt.

---

## 8. Folder structure
```
/Controllers
  HomeController.cs
  AccountController.cs
  BranchController.cs
  StaffController.cs
  ServiceController.cs
  PetController.cs
  AppointmentController.cs
  ProductController.cs
  OrderController.cs
  ReviewController.cs
  ReportController.cs
  ChatController.cs
/Models
  DB.cs                  (DbContext only — see §1)
  User.cs, Admin.cs, Staff.cs, Customer.cs   (or grouped sensibly)
  Branch.cs, Service.cs, StaffService.cs
  Pet.cs, Appointment.cs, AppointmentService.cs
  Product.cs, Order.cs, OrderLine.cs
  Review.cs, Notification.cs, RewardTransaction.cs
  ViewModels.cs           (all VMs from §5)
/Views
  _ViewImports.cshtml
  _ViewStart.cshtml
  Home/ Account/ Branch/ Staff/ Service/ Pet/ Appointment/ Product/ Order/ Review/ Report/
    Index.cshtml, Insert.cshtml, Update.cshtml, Detail.cshtml, _A.cshtml, _B.cshtml, _C.cshtml (as needed)
  Shared/_Layout.cshtml, _CheckBoxList.cshtml, _ValidationScriptsPartial.cshtml
Helper.cs
Extensions.cs
Program.cs
appsettings.json          (connection string, SMTP settings)
wwwroot/
  css/app.css
  js/app.js
  staff/  pets/  products/  services/  images/
libman.json
```

---

## 9. Seed data requirements
Provide enough sample data for a full demo, seeded via EF Core `HasData` or a `Seed` method called on startup in dev:
- 1 Admin, 3 Branches, 3–4 Staff per branch (assigned to 2–3 services each), 8–10 Services spread across branches, 10+ Products, 6–8 Customers each with 1–2 Pets, 15–20 historical Appointments across all statuses (some Completed with Reviews), a handful of Orders.
- Sample data can be pasted into the `.mdf` tables via **Server Explorer → Show Table Data** (double-click `DB.mdf` → Data Connections), same as the course's `Programs.txt`/`Students.txt` copy-paste workflow — plain tab-delimited `.txt` seed files per table are an acceptable alternative to `HasData()`.
- Include a README-ready credentials table: one login per role (Admin/Staff/Customer) with plaintext password documented for the README deliverable (Spec §6.0 item 3).

---

## 10. Build order / milestones
1. Solution scaffold + `DB.cs`/entities + migrations (`Add-Migration CreateDB` / `Update-Database`) + seed data verified in Server Explorer.
2. Security module end-to-end (register/login/logout/role menu) + `[Authorize]` scaffolding on all controllers stubbed in.
3. Branch/Staff/Service maintenance (Admin) including the Staff↔Service M:M checkbox assignment.
4. Pet management (Customer).
5. Appointment booking + availability matrix + staff-side management + status updates.
6. Product catalog + cart + checkout/orders.
7. Reviews + loyalty points ledger.
8. Additional features layered on last, per module owner: photo crop/webcam, AJAX search/sort/paging everywhere applicable (built on top of the baseline non-AJAX pattern per §0.12), QR check-in, Stripe deposit, email/SMS notifications, on-screen charts, real-time chat, Maps, login blocking, captcha, OTP verification.
9. Full role-based access audit pass + seed data polish + README credentials file + **project cleanup**: close Visual Studio, delete `.vs/`, `bin/`, `obj/`, then zip for submission (Spec §6.0).

---

## 11. Definition of done (mapped to rubric)
- [ ] Every controller/action has explicit `[Authorize]`/`[Authorize(Roles=...)]` or is deliberately public — manually audited.
- [ ] Every POST form has a ViewModel with full DataAnnotations + at least one `[Remote]` check where a uniqueness/existence rule applies, bound via Tag Helpers.
- [ ] Every GET listing page follows the baseline filter/search/sort/paging pattern (§0.12) before any AJAX enhancement is layered on.
- [ ] EF Core diagram exported from Visual Studio after final migration matches §4 exactly.
- [ ] At least one "hard" additional feature per student (matrix grid, Stripe, QR/webcam, real-time chat) in addition to easier ones (AJAX paging, etc.).
- [ ] Seed data + README credentials file present for demo.
- [ ] Project cleaned (`.vs`/`bin`/`obj` removed) before zipping for submission.
